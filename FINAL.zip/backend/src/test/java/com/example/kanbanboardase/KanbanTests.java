package com.example.kanbanboardase;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KanbanTests {

    @Test
    void contextLoads() {
    }

}
