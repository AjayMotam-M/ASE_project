package com.example.kanbanboardase.kanbanboardase.services;

import com.example.kanbanboardase.kanbanboardase.dto.CreateUserDto;
import com.example.kanbanboardase.kanbanboardase.dto.LoginUserDto;
import com.example.kanbanboardase.kanbanboardase.dto.ServiceResponse;
import com.example.kanbanboardase.kanbanboardase.models.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AuthenticationService implements IAuthService {

    private final IPasswordService passwordService;
    private final IUserService userService;

    @Autowired
    public AuthenticationService(IPasswordService passwordService, IUserService userService) {
        this.passwordService = passwordService;
        this.userService = userService;
    }

    @Override
    public ServiceResponse<String> verifyLogin(LoginUserDto loginUserDto) {
        User user = userService.getByEmail(loginUserDto.getEmail());

        boolean isPasswordValid = passwordService.verifyPassword(loginUserDto.getPassword(), user.getPassword());
        if (!isPasswordValid) {
            return new ServiceResponse<>("Invalid credentials", false, null);
        }

        return new ServiceResponse<>("User verified successfully", true, user.getId());
    }

    @Override
    public ServiceResponse<String> register(CreateUserDto createUserDto) {
        ServiceResponse<String> userResponse = userService.create(createUserDto);

        if (userResponse.isSuccess()) {
            return new ServiceResponse<>("User created successfully", userResponse.getData());
        }

        return new ServiceResponse<>(userResponse.getMessage(), false, userResponse.getData());
    }
}
