package com.example.kanbanboardase.kanbanboardase.services;

import com.example.kanbanboardase.kanbanboardase.dto.CreateProjectDto;
import com.example.kanbanboardase.kanbanboardase.dto.ServiceResponse;
import com.example.kanbanboardase.kanbanboardase.dto.UpdateProjectDto;
import com.example.kanbanboardase.kanbanboardase.middleware.NotFoundException;
import com.example.kanbanboardase.kanbanboardase.models.Project;
import com.example.kanbanboardase.kanbanboardase.models.User;
import com.example.kanbanboardase.kanbanboardase.repository.BoardRepository;
import com.example.kanbanboardase.kanbanboardase.repository.UserRepository;
import com.example.kanbanboardase.kanbanboardase.utils.BuildResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class ProjectService implements IBoardService {
    private final BoardRepository boardRepository;
    private final UserRepository userRepository;

    @Autowired
    public ProjectService(BoardRepository boardRepository, UserRepository userRepository) {
        this.boardRepository = boardRepository;
        this.userRepository = userRepository;
    }

    @Override
    public ServiceResponse<List<BuildResponse>> getBoards() {
        List<Project> projects = boardRepository.findByIsPublic(true);

        List<BuildResponse> buildResponse = projects.stream()
                .map(BuildResponse::fromEntity)
                .collect(Collectors.toList());

        return new ServiceResponse<>("Board retrieved successfully", buildResponse);
    }

    @Override
    public ServiceResponse<BuildResponse> getById(String id) {
        Project project = boardRepository.findById(id).orElseThrow(
                () -> new NotFoundException("Board not found")
        );

        BuildResponse buildResponse = BuildResponse.fromEntity(project);
        return new ServiceResponse<>("Board retrieved successfully", buildResponse);
    }

    @Override
    public ServiceResponse<String> updateData(String id, UpdateProjectDto updateProjectDto) {
        Project existingProject = boardRepository.findById(id).orElseThrow(
                () -> new NotFoundException("Board not found")
        );

        existingProject.setData(updateProjectDto.getData());
        boardRepository.save(existingProject);
        return new ServiceResponse<>("Board updated successfully", existingProject.getId());
    }

    @Override
    public ServiceResponse<String> create(CreateProjectDto newBoard) {
        User user = userRepository.findById(newBoard.getUserId()).orElseThrow(
                () -> new NotFoundException("User not found")
        );

        Project createdProject = new Project();
        createdProject.setUser(user);
        createdProject.setName(newBoard.getName());
        createdProject.setDescription(newBoard.getDescription());
        createdProject.setIsPublic(newBoard.getIsPublic());
        createdProject.setData(newBoard.getData());

        boardRepository.save(createdProject);
        return new ServiceResponse<>("Board created successfully", createdProject.getId());
    }

    @Override
    public ServiceResponse<Void> delete(String id) {
        Project project = boardRepository.findById(id).orElseThrow(
                () -> new NotFoundException("Board not found")
        );

        boardRepository.delete(project);
        return new ServiceResponse<>("Board deleted successfully", true, null);
    }

    @Override
    public ServiceResponse<List<BuildResponse>> getBoardsByUserId(String userId) {
        List<Project> projects = boardRepository.findByUserId(userId);

        List<BuildResponse> buildResponse = projects.stream()
                .map(BuildResponse::fromEntity)
                .collect(Collectors.toList());

        return new ServiceResponse<>("Boards retrieved successfully", buildResponse);
    }

    @Override
    public ServiceResponse<Void> togglePublic(String id) {
        Project project = boardRepository.findById(id).orElseThrow(
                () -> new NotFoundException("Board not found")
        );

        project.setIsPublic(!project.getIsPublic());
        boardRepository.save(project);
        return new ServiceResponse<>("Board updated successfully", null);
    }

}
