package com.example.kanbanboardase.kanbanboardase.utils;

import com.example.kanbanboardase.kanbanboardase.models.Project;
import com.example.kanbanboardase.kanbanboardase.models.User;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BuildResponse {

    private String id;
    private String name;
    private String description;
    private Boolean isPublic;
    private String data;
    private UserResponse user;

    public static BuildResponse fromEntity(Project project) {
        User user = project.getUser();

        UserResponse userResponse = UserResponse.builder()
                .id(user.getId())
                .name(user.getName())
                .email(user.getEmail())
                .build();


        BuildResponse buildResponse = BuildResponse.builder()
                .id(project.getId())
                .name(project.getName())
                .description(project.getDescription())
                .isPublic(project.getIsPublic())
                .data(project.getData())
                .user(userResponse)
                .build();

        return buildResponse;
    }
}