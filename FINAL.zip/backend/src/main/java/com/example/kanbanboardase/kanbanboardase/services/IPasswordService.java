package com.example.kanbanboardase.kanbanboardase.services;

public interface IPasswordService {
    String hashPassword(String password);

    boolean verifyPassword(String rawPassword, String encodedPassword);
}
