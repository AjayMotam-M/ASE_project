/* eslint-disable @typescript-eslint/no-explicit-any */
const baseUrl = process.env.BACKEND_URL

export const getAllUsers = async () => {
  const response = await fetch(`${baseUrl}/users`, {
    method: 'GET',
    headers: {
      Accept: 'application/json',
    },
  })
  return await response.json()
}

export const getUserById = async (userId: string) => {
  const response = await fetch(`${baseUrl}/users/${userId}`, {
    method: 'GET',
    headers: {
      Accept: 'application/json',
    },
  })
  return await response.json()
}

export const updateUserPassword = async (
  userId: string,
  newPassword: string
) => {
  const response = await fetch(`${baseUrl}/users/${userId}/password`, {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ password: newPassword }),
  })
  return await response.json()
}

export const getPublicBoards = async () => {
  const response = await fetch(`${baseUrl}/board/public`, {
    method: 'GET',
  })
  return await response.json()
}

export const getBoardById = async (boardId: string) => {
  const response = await fetch(`${baseUrl}/board/${boardId}`, {
    method: 'GET',
  })
  return await response.json()
}

export const getBoardsForUser = async (userId: string) => {
  const response = await fetch(`${baseUrl}/board/user/${userId}`, {
    method: 'GET',
  })
  return await response.json()
}

export const createBoard = async (boardData: any) => {
  const response = await fetch(`${baseUrl}/board`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(boardData),
  })
  return await response.json()
}

export const deleteBoard = async (boardId: string) => {
  const response = await fetch(`${baseUrl}/board/${boardId}`, {
    method: 'DELETE',
  })
  return await response.json()
}

export const updateBoardData = async (boardId: string, newData: any) => {
  const response = await fetch(`${baseUrl}/board/${boardId}/update-data`, {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ data: newData }),
  })
  return await response.json()
}

export const registerUser = async (userData: any) => {
  const response = await fetch(`${baseUrl}/auth/join`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(userData),
  })
  return await response.json()
}

export const verifyLogin = async (loginData: any) => {
  const response = await fetch(`${baseUrl}/auth/verify`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(loginData),
  })
  return await response.json()
}
