import { useSubmit } from '@remix-run/react'

import { Button } from './ui/button'

export function UserNav() {
  const submit = useSubmit()

  return (
    <Button
      variant="ghost"
      className="text-black hover:text-black/80 cursor-pointer"
      onClick={() =>
        submit(null, {
          method: 'post',
          action: '/logout',
        })
      }
    >
      Logout
    </Button>
  )
}
