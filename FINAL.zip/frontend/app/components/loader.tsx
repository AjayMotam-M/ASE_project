import { Loader2Icon } from 'lucide-react'

export default function Loader() {
  return <Loader2Icon size={32} className="animate-spin text-slate-300" />
}
