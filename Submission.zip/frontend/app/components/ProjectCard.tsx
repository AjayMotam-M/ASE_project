import { Link } from '@remix-run/react'

import { Button } from '~/components/ui/button'
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '~/components/ui/card'
import { DeleteBoardButton } from '~/routes/resources+/delete-board'
import { useProjects } from '~/utils'

interface ProjectCardProps {
  project: ReturnType<typeof useProjects>['publicProjects'][0]
  canEdit: boolean
}
export function ProjectCard({ project, canEdit }: ProjectCardProps) {
  return (
    <Card className="bg-blue-700 p-4 group rounded-none border-none min-h-[300px] flex flex-col">
      <CardHeader className="relative ">
        <CardTitle className="text-3xl font-bold text-white">
          {project.name}
        </CardTitle>
        <CardDescription className="flex flex-col gap-2 text-sm text-white">
          <p className="mt-4">
            <b>Description:</b> <span>{project.description}</span>
          </p>
          <p>
            <b>Owner:</b> <span>{project.user.name}</span>
          </p>
        </CardDescription>
        {canEdit ? <DeleteBoardButton boardId={project.id} /> : null}
      </CardHeader>

      <CardContent className="text-sm text-white flex-1">
        <div className="flex items-center space-x-2">
          <b>Created at:</b>{' '}
          <span>
            <span>{new Date(project.created_at).toLocaleDateString()}</span>
          </span>
        </div>
      </CardContent>
      <CardFooter className="w-full mt-6">
        <Button variant="secondary" className="px-3 shadow-none w-full" asChild>
          <Link to={`/dashboard/${project.id}`} className="flex items-center">
            View
          </Link>
        </Button>
      </CardFooter>
    </Card>
  )
}
