package com.example.kanbanboardase.kanbanboardase.middleware;

public class NotFoundException extends RuntimeException {
    public NotFoundException(String message) {
        super(message);
    }
}
