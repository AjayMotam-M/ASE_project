package com.example.kanbanboardase.kanbanboardase.controller;

import com.example.kanbanboardase.kanbanboardase.dto.CreateProjectDto;
import com.example.kanbanboardase.kanbanboardase.dto.ServiceResponse;
import com.example.kanbanboardase.kanbanboardase.dto.UpdateProjectDto;
import com.example.kanbanboardase.kanbanboardase.services.IBoardService;
import com.example.kanbanboardase.kanbanboardase.utils.BuildResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/board")
public class ProjectController {
    private final IBoardService boardService;

    @Autowired
    public ProjectController(IBoardService boardService) {
        this.boardService = boardService;
    }

    @GetMapping("/public")
    public ResponseEntity<ServiceResponse<List<BuildResponse>>> getPublicBoards() {
        ServiceResponse<List<BuildResponse>> response = boardService.getBoards();
        if (!response.isSuccess()) {
            return ResponseEntity.badRequest().body(response);
        }

        return ResponseEntity.ok(response);
    }

    @GetMapping("/{id}")
    public ResponseEntity<ServiceResponse<BuildResponse>> getUserById(@PathVariable String id) {
        ServiceResponse<BuildResponse> response = boardService.getById(id);
        if (!response.isSuccess()) {
            return ResponseEntity.badRequest().body(response);
        }

        return ResponseEntity.ok(response);
    }

    @PostMapping
    public ResponseEntity<ServiceResponse<String>> create(@RequestBody CreateProjectDto newBoard) {
        ServiceResponse<String> response = boardService.create(newBoard);
        if (!response.isSuccess()) {
            return ResponseEntity.badRequest().body(response);
        }

        return ResponseEntity.ok(response);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<ServiceResponse<Void>> delete(@PathVariable String id) {
        ServiceResponse<Void> response = boardService.delete(id);
        if (!response.isSuccess()) {
            return ResponseEntity.badRequest().body(response);
        }

        return ResponseEntity.ok(response);
    }


    @PutMapping("/{id}/update")
    public ResponseEntity<ServiceResponse<String>> updateData(@PathVariable String id, @RequestBody UpdateProjectDto updateProjectDto) {
        ServiceResponse<String> response = boardService.updateData(id, updateProjectDto);
        if (!response.isSuccess()) {
            return ResponseEntity.badRequest().body(response);
        }

        return ResponseEntity.ok(response);
    }
}
