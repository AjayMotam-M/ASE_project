package com.example.kanbanboardase.kanbanboardase.services;

import com.example.kanbanboardase.kanbanboardase.dto.CreateUserDto;
import com.example.kanbanboardase.kanbanboardase.dto.LoginUserDto;
import com.example.kanbanboardase.kanbanboardase.dto.ServiceResponse;

public interface IAuthService {
    ServiceResponse<String> verifyLogin(LoginUserDto loginUserDto);

    ServiceResponse<String> register(CreateUserDto createUserDto);
}
