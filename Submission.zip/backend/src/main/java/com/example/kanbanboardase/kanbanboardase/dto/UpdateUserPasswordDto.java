package com.example.kanbanboardase.kanbanboardase.dto;

import lombok.Getter;

@Getter
public class UpdateUserPasswordDto {
    private String password;


}
