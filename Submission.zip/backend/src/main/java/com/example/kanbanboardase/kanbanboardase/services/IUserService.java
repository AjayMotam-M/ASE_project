package com.example.kanbanboardase.kanbanboardase.services;

import com.example.kanbanboardase.kanbanboardase.dto.CreateUserDto;
import com.example.kanbanboardase.kanbanboardase.dto.ServiceResponse;
import com.example.kanbanboardase.kanbanboardase.dto.UpdateUserPasswordDto;
import com.example.kanbanboardase.kanbanboardase.models.User;

import java.util.List;

public interface IUserService {
    ServiceResponse<List<User>> findAll();

    ServiceResponse<User> getById(String id);

    ServiceResponse<String> create(CreateUserDto userDto);

    ServiceResponse<String> updatePassword(String userId, UpdateUserPasswordDto updateUserPasswordDto);

    User getByEmail(String email);

    boolean emailExists(String email);
}
