package com.example.kanbanboardase.kanbanboardase.services;

import com.example.kanbanboardase.kanbanboardase.dto.CreateProjectDto;
import com.example.kanbanboardase.kanbanboardase.dto.ServiceResponse;
import com.example.kanbanboardase.kanbanboardase.dto.UpdateProjectDto;
import com.example.kanbanboardase.kanbanboardase.utils.BuildResponse;

import java.util.List;

public interface IBoardService {

    ServiceResponse<List<BuildResponse>> getBoards();

    ServiceResponse<BuildResponse> getById(String id);

    ServiceResponse<String> updateData(String id, UpdateProjectDto updateProjectDto);

    ServiceResponse<String> create(CreateProjectDto newBoard);

    ServiceResponse<Void> delete(String id);

    ServiceResponse<List<BuildResponse>> getBoardsByUserId(String userId);

    ServiceResponse<Void> togglePublic(String id);


}
