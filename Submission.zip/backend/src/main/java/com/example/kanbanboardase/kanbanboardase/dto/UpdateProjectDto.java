package com.example.kanbanboardase.kanbanboardase.dto;

import lombok.Getter;

@Getter
public class UpdateProjectDto {
    private String data;

}
