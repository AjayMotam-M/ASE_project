package com.example.kanbanboardase.kanbanboardase.controller;

import com.example.kanbanboardase.kanbanboardase.dto.ServiceResponse;
import com.example.kanbanboardase.kanbanboardase.dto.UpdateUserPasswordDto;
import com.example.kanbanboardase.kanbanboardase.models.User;
import com.example.kanbanboardase.kanbanboardase.services.IUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/users")
public class UserController {

    private final IUserService userService;

    @Autowired
    public UserController(IUserService userService) {
        this.userService = userService;
    }

    @GetMapping
    public ResponseEntity<ServiceResponse<List<User>>> getUsers() {
        return ResponseEntity.ok(userService.findAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<ServiceResponse<User>> getUserById(@PathVariable String id) {
        return ResponseEntity.ok(userService.getById(id));
    }


    @PutMapping("/{id}/update-password")
    public ResponseEntity<ServiceResponse<String>> updatePassword(@PathVariable String id, @RequestBody UpdateUserPasswordDto updateUserPasswordDto) {
        ServiceResponse<String> response = userService.updatePassword(id, updateUserPasswordDto);

        if (response.isSuccess()) {
            return ResponseEntity.ok(response);
        }

        return ResponseEntity.badRequest().body(response);
    }
}
