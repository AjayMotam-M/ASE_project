package com.example.kanbanboardase.kanbanboardase.controller;

import com.example.kanbanboardase.kanbanboardase.dto.CreateUserDto;
import com.example.kanbanboardase.kanbanboardase.dto.LoginUserDto;
import com.example.kanbanboardase.kanbanboardase.dto.ServiceResponse;
import com.example.kanbanboardase.kanbanboardase.services.IAuthService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/auth")
public class AuthController {

    private final IAuthService authService;

    @Autowired
    public AuthController(IAuthService authService) {
        this.authService = authService;
    }

    @PostMapping("/verify")
    public ResponseEntity<ServiceResponse<String>> verifyLogin(@RequestBody LoginUserDto loginUserDto) {
        ServiceResponse<String> response = authService.verifyLogin(loginUserDto);

        if (response.isSuccess()) {
            return ResponseEntity.ok(response);
        }

        return ResponseEntity.badRequest().body(response);
    }

    @PostMapping("/join")
    public ResponseEntity<ServiceResponse<String>> register(@RequestBody CreateUserDto createUserDto) {
        ServiceResponse<String> response = authService.register(createUserDto);

        if (response.isSuccess()) {
            return ResponseEntity.ok(response);
        }

        return ResponseEntity.badRequest().body(response);
    }


}
